﻿#include"global_var.h"
Banksql *S=new Banksql();
QString card_id="";
QString card_type="";
bool login=false;
bool adminlogin=false;
