﻿#ifndef GLOBAL_VAR_H
#define GLOBAL_VAR_H
#include "banksql.h"
extern  Banksql *S;//数据库
extern QString card_id;//卡号
extern QString card_type;//卡类别
extern bool login;//用户登录认证
extern bool adminlogin;//管理员登录认证
#endif // GLOBAL_VAR_H
